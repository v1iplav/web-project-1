from django.shortcuts import render,redirect
from django.shortcuts import HttpResponse
from . models import App1

# Create your views here.

def index(request):
      if request.method=='POST':
            name=request.POST['name']
            email=request.POST.get('email')
            subject=request.POST['subject']
            message=request.POST['message']

            x=App1(name=name,email=email,subject=subject,message=message)
            x.save() 
      return render(request,'index.html')

